using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class customer_image : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    string pno, pname;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        pno = Request.QueryString["pno"];
        pname = Request.QueryString["pname"];
        da = new SqlDataAdapter("select * from supplprod_tb where pname='" + pname + "' and pno='" + pno + "' ", conn);
        da.Fill(ds, "pp");
        Image1.ImageUrl = ds.Tables["pp"].Rows[0][8].ToString();
    }
}
