using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class customer_pay : System.Web.UI.Page
{
    float pay;
    string on,dd,yy;
    DateTime dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        pay= float.Parse(Session["pay"].ToString());
        on = Session["on"].ToString();
        lbltran.Text = pay.ToString();
        lbltid.Text = on;
        dt = DateTime.Parse(System.DateTime.Now.ToString());
        dd = dt.Date.ToShortDateString();
        yy = dt.Year.ToString();
        if (this.IsPostBack == false)
        {
            year();
        }
        lblMsg.Visible = false;
    }

    void year()
    {

        int i = 20, j = 1;
        ddlyy.Items.Insert(1, yy);
        for (i = 0; i <= 20; i++)
        {

            int ye = int.Parse(yy.ToString()) + j;
            string yea = ye.ToString();
            ddlyy.Items.Insert(j, yea);
            j = j + 1;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        lblMsg.Visible = false;
        if (!validate())
        {
            Session["on"] = on;
            Session["pay"] = pay;
            Session["dd"] = dd;
            Response.Redirect("~/customer/trans.aspx");
        }
        else
        {
            lblMsg.Visible = true;
        }
    }

    private bool validate()
    {
        bool isValidated = false;
        if(txtcno.Text.Trim() == string.Empty || txtname.Text.Trim() == string.Empty || ddlmm.SelectedIndex == 0 || ddlyy.SelectedIndex == 0)
            isValidated = true;
        return isValidated;
    }
}
