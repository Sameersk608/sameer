using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class customer_customerMasterPage : System.Web.UI.MasterPage
{
    string custid;
    SqlConnection conn;
    Dbconn con;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        custid = Session["custid"].ToString();
        Session["custid"] = custid;
        Session["pno"] = "";
        Session["name"] = "";
        if (this.IsPostBack == false)
        {
            prod();
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/customer/modifyprofile.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/customer/changepassword.aspx");
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/customer/ViewProducts.aspx");
    }
    protected void LinkButton6_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/customer/Buy Products.aspx");
    }
    //protected void LinkButton4_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/customer/vieworders.aspx");
    //}
   protected void LinkButton8_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/customer/Register.aspx");
    }
    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/customer/login.aspx");
    }
    protected void LinkButton9_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/customer/AddtoCart1.aspx");
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    void prod()
    {
        da = new SqlDataAdapter("select * from product_tb", conn);
        da.Fill(ds, "prod");
        ddlpname.DataSource = ds.Tables["prod"];
        ddlpname.DataTextField = "prodname";
        ddlpname.DataValueField = "pno";
        ddlpname.DataBind();
        ddlpname.Items.Insert(0, "--Select Categories--");
        ddlpname.Dispose();

        if (!string.IsNullOrEmpty(Convert.ToString(Session["CustName"])))
        {
            LinkButton7.Visible = false;
            lblOr.Visible = false;
            LinkButton8.Visible = false;
            lblName.Text = Convert.ToString(Session["CustName"]);
        }
        else
        {
            LinkButton7.Visible = true;
            lblOr.Visible = true;
            LinkButton8.Visible = true;
            lblName.Text = "";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "" && ddlpname.SelectedIndex != 0)
        {
            string pno = ddlpname.SelectedValue;
            Session["pno"] = pno;
            Session["name"] = "";
            Session["cust"] = custid;
            Response.Redirect("~/customer/Buy Products.aspx");
        }
        else
        {
            string pno = ddlpname.SelectedValue;
            string name = TextBox1.Text;
            Session["pno"] = pno;
            Session["name"] = name;
            Session["custid"] = custid;
            Response.Redirect("~/customer/Buy Products.aspx");
        }
    }
    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Session["CustName"] = "";
        Response.Redirect("~/homepage1.aspx");
    }
    protected void LinkButton11_Click(object sender, EventArgs e)
    {
        Session["CustName"] = "";
        Response.Redirect("~/homepage1.aspx");
    }
    protected void LinkButton13_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/customer/questionary.aspx");
    }
    protected void LinkButton14_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/customer/answer.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/customer/checkmails.aspx");
    }
}
