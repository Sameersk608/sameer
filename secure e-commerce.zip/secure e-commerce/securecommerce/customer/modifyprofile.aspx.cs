using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class customer_modifyprofile : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    string custid;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        custid = Session["custid"].ToString();
        if (this.IsPostBack == false)
        {
            state();
            country();
            city();
        }
    }
    void state()
    {
        da = new SqlDataAdapter("select * from dbo.state_tb", conn);
        da.Fill(ds, "state");
        ddlstate.DataSource = ds.Tables["state"];
        ddlstate.DataTextField = "statename";
        ddlstate.DataValueField = "stateid";
        ddlstate.DataBind();
        ddlstate.Items.Insert(0, "--Select--");
        ddlstate.Dispose();
    }
    void country()
    {
        da = new SqlDataAdapter("select * from dbo.country_tb", conn);
        da.Fill(ds, "country");
        ddlcountry.DataSource = ds.Tables["country"];
        ddlcountry.DataTextField = "cname";
        ddlcountry.DataValueField = "cno";
        ddlcountry.DataBind();
        ddlcountry.Items.Insert(0, "--Select--");
        ddlcountry.Dispose();
    }
    void city()
    {
        da = new SqlDataAdapter("select * from dbo.city_tb", conn);
        da.Fill(ds, "city");
        ddlcity.DataSource = ds.Tables["city"];
        ddlcity.DataTextField = "cityname";
        ddlcity.DataValueField = "cityid";
        ddlcity.DataBind();
        ddlcity.Items.Insert(0, "--Select--");
        ddlcity.Dispose();
    }
    protected void cmdUpdateProfile_Click1(object sender, EventArgs e)
    {
    da = new SqlDataAdapter("update  customerdetail_tb set emailid='"+txtEmail.Text+"',address='"+txtAddress.Text+"',city='"+ddlstate.SelectedItem.Text+"',state='"+ddlstate.SelectedItem.Text+"',country='"+ddlcountry.SelectedItem.Text+"',zip='"+txtPostalCode.Text+"',phoneno='"+txtPhone.Text+"' where custid='"+custid+"'", conn);
        int i = da.SelectCommand.ExecuteNonQuery();
        if (i == 1)
        {
            lblmsg.Text = "Your Details are Updated";
        }
        else
        {
            lblmsg.Text = "Your Details are not Updated";
        }
    }
}
