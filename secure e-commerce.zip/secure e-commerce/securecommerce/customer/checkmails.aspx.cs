using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class customer_checkmails : System.Web.UI.Page
{
    Dbconn con;
    SqlConnection conn;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    string custid;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        custid = Session["custid"].ToString();
        detail();
    }
    protected void ImageButton1_Click(object sender, CommandEventArgs e)
    {
        int arg = int.Parse(e.CommandArgument.ToString());
        conn.Open();
        da=new SqlDataAdapter("delete mailsent_tb where sno='"+arg+"'",conn);
        da.SelectCommand.ExecuteNonQuery();
        conn.Close();
        detail();
    }
    void detail()
    {
        da=new SqlDataAdapter("select * from mailsent_tb where tocust='"+custid+"'",conn);
        da.Fill(ds, "de");
        GridView1.DataSource = ds.Tables["de"];
        GridView1.DataBind();
        
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
   
    {
        GridView1.PageIndex = e.NewPageIndex;
        detail();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

  }
  
}
