using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class customer_ViewProducts : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    string custid;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
       // gridprod();
        custid = Session["custid"].ToString();
        if (this.IsPostBack == false)
        {
           prod();
        }
    }
    void gridprod()
    {
        da = new SqlDataAdapter("select * from product_tb", conn);
        da.Fill(ds, "gp");
        GridView1.DataSource = ds.Tables["gp"];
        GridView1.DataBind();
    }
    void prod()
    {
        da = new SqlDataAdapter("select * from product_tb", conn);
        da.Fill(ds, "prod");
        ddlpname.DataSource = ds.Tables["prod"];
        ddlpname.DataTextField = "prodname";
        ddlpname.DataValueField = "pno";
        ddlpname.DataBind();
        ddlpname.Items.Insert(0, "--Select Categories--");
        ddlpname.Dispose();
    }
    protected void ddlpname_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlpname.SelectedIndex != 0)
        {
            da = new SqlDataAdapter("select * from supplprod_tb where pno='"+ddlpname.SelectedValue+"'", conn);
            da.Fill(ds, "sp");
            GridView2.DataSource = ds.Tables["sp"];
            GridView2.DataBind();
        }
    }
    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView2.PageIndex = e.NewPageIndex;
        da = new SqlDataAdapter("select * from supplprod_tb where pno='" + ddlpname.SelectedValue + "'", conn);
        da.Fill(ds, "sp");
        GridView2.DataSource = ds.Tables["sp"];
        GridView2.DataBind();
    }
}
