using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class customer_trans : System.Web.UI.Page
{
    string dd, on;
    float pay;
    protected void Page_Load(object sender, EventArgs e)
    {
        dd = Session["dd"].ToString();
        on = Session["on"].ToString();
        pay = float.Parse(Session["pay"].ToString());
        lblamt.Text = pay.ToString();
        lblid.Text = on;
        lbltdate.Text = dd;
    }
}
