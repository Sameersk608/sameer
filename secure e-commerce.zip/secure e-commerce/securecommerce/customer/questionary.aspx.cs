using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class customer_questionary : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlDataAdapter da;
    SqlCommand cmd;
    SqlDataReader dr;
    DataSet ds = new DataSet();
    int qno;
    string custid;
    protected void Page_Load(object sender, EventArgs e)
    { 
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        custid = Session["custid"].ToString();
        if (this.IsPostBack == false)
        {
            supp();
        }

    }
    void supp()
    {
        da = new SqlDataAdapter("select * from supplierdetail_tb", conn);
        da.Fill(ds, "sup");
        ddlsupp.DataSource = ds.Tables["sup"];
        ddlsupp.DataTextField = "fname";
        ddlsupp.DataValueField = "supplierid";
        ddlsupp.DataBind();
        ddlsupp.Items.Insert(0, "--Select--");
    }
    void prod()
    {
        da = new SqlDataAdapter("select * from supplprod_tb where supplierid='" + ddlsupp.SelectedValue + "'", conn);
        da.Fill(ds, "prod");
        ddlpname.DataSource = ds.Tables["prod"];
        ddlpname.DataTextField = "pname";
        ddlpname.DataValueField = "sno";
        ddlpname.DataBind();
        ddlpname.Items.Insert(0, "--Select Categories--");
        ddlpname.Dispose();
    }
    protected void ddlsupp_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlsupp.SelectedIndex != 0)
        {
            prod();
        }
    }
    void qno1()
    {
        da = new SqlDataAdapter("select count(quesno) from question", conn);
        da.Fill(ds, "ss");
        int k = int.Parse(ds.Tables["ss"].Rows[0][0].ToString());
        if (k > 0)
        {
            cmd = new SqlCommand("select max(quesno) from question", conn);
            dr = cmd.ExecuteReader();
            dr.Read();
            int i = int.Parse(dr[0].ToString());
            dr.Close();
            qno = i + 1;
        }
        else
        {
            qno = 1;
        }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        qno1();
        da = new SqlDataAdapter("insert into question values('"+qno+"','"+ddlsupp.SelectedValue+"','"+ddlpname.SelectedValue+"','"+RadioButtonList1.SelectedItem.Text+"','"+txtech.Text+"','"+txtper.Text+"','"+custid+"','')", conn);

     //  da.SelectCommand.ExecuteNonQuery();
        int i = da.SelectCommand.ExecuteNonQuery();
        if (i == 1)
        {
            lblmsg.Text = "Your Details are Updated";
        }
        else
        {
            lblmsg.Text = "Your Details are not Updated";
        }
    }
       
    
}
