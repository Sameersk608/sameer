using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class customer_AddtoCart1 : System.Web.UI.Page
{
    Dbconn con;
    SqlConnection conn;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    string custid;
    DateTime dt;
    string dt1, on;
    float totalcost1,totalcost2;
    Random r = new Random();
 
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        // custid = "CI00001";
        custid = Session["custid"].ToString();
        dt = DateTime.Parse(DateTime.Now.ToString("MM/dd/yy"));
        dt1 = dt.ToShortDateString();
        griddetails();
        total();
    }
    void griddetails()
    {
        da = new SqlDataAdapter("select * from cart_tb where custid='" + custid + "' and date='" + dt1 + "'", conn);
        da.Fill(ds, "gg");
        GridView1.DataSource = ds.Tables["gg"];
        GridView1.DataBind();
        for (int k = 0; k < ds.Tables["gg"].Rows.Count; k++)
        {
            foreach (GridViewRow r3 in GridView1.Rows)
            {
                TextBox qt = (TextBox)r3.FindControl("txtqty");
                qt.Text = ds.Tables["gg"].Rows[k][8].ToString();
            }
        }
    }
    void total()
    {
        foreach (GridViewRow r1 in GridView1.Rows)
        {

            TextBox qty = (TextBox)r1.FindControl("txtqty");
            int qty1 = int.Parse(qty.Text.ToString());
            float c = float.Parse(r1.Cells[4].Text.ToString());
            float tc = qty1 * c;
            r1.Cells[6].Text = tc.ToString();
            totalcost1 += tc;
        }
        lbltotcost.Text = totalcost1.ToString();
    }
    //protected void btndelete_Click(object sender, CommandEventArgs  e)
    //{
    //    arg = int.Parse(e.CommandArgument.ToString());
    //    da = new SqlDataAdapter("delete cart_tb where sno='" + arg + "'", conn);
    //    da.SelectCommand.ExecuteNonQuery();
    //}
    protected void ImageButton1_Click(object sender, CommandEventArgs e)
    {
        int arg = int.Parse(e.CommandArgument.ToString());
        da=new SqlDataAdapter("delete cart_tb where sno='"+arg+"'",conn);
        da.SelectCommand.ExecuteNonQuery();
      da=new SqlDataAdapter("select * from cart_tb where custid='"+custid+"' and date='"+dt1+"'",conn);
      da.Fill(ds, "de");
      GridView1.DataSource = ds.Tables["de"];
      GridView1.DataBind();
      for (int i = 0; i < ds.Tables["de"].Rows.Count; i++)
      {
          foreach (GridViewRow r1 in GridView1.Rows)
          {
              TextBox qt = (TextBox)r1.FindControl("txtqty");
              qt.Text = ds.Tables["gg"].Rows[i][8].ToString();           
          }        
      }
      foreach (GridViewRow r2 in GridView1.Rows)
      {
          TextBox qty = (TextBox)r2.FindControl("txtqty");
          int qty1 = int.Parse(qty.Text.ToString());
          float c = float.Parse(r2.Cells[4].Text.ToString());
          float tc = qty1 * c;
          r2.Cells[6].Text = tc.ToString();
          totalcost2 += tc;
      }
        lbltotcost.Text = totalcost2.ToString();
     
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        on = "ON" + r.Next(10, 999).ToString();
        Session["pay"] = lbltotcost.Text;
        Session["on"] = on;
        Response.Redirect("~/customer/pay.aspx");
    }
}
