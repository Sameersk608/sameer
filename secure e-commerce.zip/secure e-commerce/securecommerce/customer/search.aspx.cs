using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class customer_search : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    string custid;
    int sno;
    string arg;
    string pno;
    string name;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        //custid = "CI00001";
        custid = Session["custid"].ToString();
        pno = Session["pno"].ToString();
        name = Session["name"].ToString();
        griddetails();
    }
    void griddetails()
    {
        if (name == "")
        {
            da = new SqlDataAdapter("select * from supplprod_tb where pno='" + pno + "' and Status='Avaliable' ", conn);
            da.Fill(ds, "sp");
            GridView1.DataSource = ds.Tables["sp"];
            GridView1.DataBind();
        }
        else if (pno == "" && name == "")
        {
        }
        else
        {
            da = new SqlDataAdapter("select * from supplprod_tb where pno='" + pno + "' and pname like '" + name + "'+'%' and Status='Avaliable'", conn);
            da.Fill(ds, "sp1");
            GridView1.DataSource = ds.Tables["sp1"];
            GridView1.DataBind();
        }
    }
    void sno1()
    {
        da = new SqlDataAdapter("select count(sno) from cart_tb", conn);
        da.Fill(ds, "ss");
        int k = int.Parse(ds.Tables["ss"].Rows[0][0].ToString());
        if (k > 0)
        {
            cmd = new SqlCommand("select max(sno) from cart_tb", conn);
            dr = cmd.ExecuteReader();
            dr.Read();
            int i = int.Parse(dr[0].ToString());
            dr.Close();
            sno = i + 1;
        }
        else
        {
            sno = 1;
        }

    }
    protected void LinkButton1_Click(object sender, CommandEventArgs e)
    {
        if (custid != "")
        {
            sno1();
            arg = e.CommandArgument.ToString();
            da = new SqlDataAdapter("select * from supplprod_tb where sno='" + arg + "'", conn);
            da.Fill(ds, "arg");
            string pno = ds.Tables["arg"].Rows[0][2].ToString();
            string prodname = ds.Tables["arg"].Rows[0][3].ToString();
            string pname = ds.Tables["arg"].Rows[0][4].ToString();
            float price = float.Parse(ds.Tables["arg"].Rows[0][5].ToString());
            string logo = ds.Tables["arg"].Rows[0][8].ToString();
            da = new SqlDataAdapter("insert into cart_tb values('" + sno + "','" + custid + "','" + pno + "','" + prodname + "','" + pname + "','" + price + "','" + logo + "','" + System.DateTime.Now.ToShortDateString() + "','" + 1 + "','" + price + "')", conn);
            da.SelectCommand.ExecuteNonQuery();
        }
        griddetails();
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "rr")
        {
        }
    }
}
