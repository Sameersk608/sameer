using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class customer_changepassword : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    string custid;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        custid = Session["custid"].ToString();
    }
    protected void cmdChangePassword_Click(object sender, EventArgs e)
    {
        da = new SqlDataAdapter("update  customerdetail_tb set password='" + txtNewPassword.Text + "' where custid='"+custid+"'", conn);
        int i = da.SelectCommand.ExecuteNonQuery();
        if (i == 1)
        {
            lblmsg.Text = "Your Password is Changed";
        }
        else
        {
            lblmsg.Text = "Your Password is not Changed";
        }
        
    }
    //protected void txtOldPassword_TextChanged(object sender, EventArgs e)
    //{
    // //   conn.Open();
    //    cmd = new SqlCommand("select count(password) from customerdetail_tb where custid='CI00001' ", conn);
    //    dr=cmd.ExecuteReader();
    //    dr.Read();
    //    rowcnt = int.Parse(dr[0].ToString());
    //    dr.Close();
    //    if (rowcnt > 0)
    //    {
    //        da = new SqlDataAdapter("select password from customerdetail_tb where custid='CI00001'", conn);
    //        da.Fill(ds, "pp");
    //        string pwd = ds.Tables["pp"].Rows[0][0].ToString();
    //        if (pwd == txtOldPassword.Text)
    //        {
    //            lblerrmsg.Text = "";
    //        }
    //        else
    //        {
    //            lblerrmsg.Text = "Invalid Password";
    //        }
    //    }
      

    //}
}
