using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class customer_answer : System.Web.UI.Page
{
    Dbconn con;
    SqlConnection conn;
    SqlDataAdapter da;
    SqlDataReader dr;
    DataSet ds = new DataSet();
    SqlCommand cmd;
    string custid,arg,dt1;
    DateTime dt;
    int sno;
    string pno;
    string name;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        // custid = "CI00001";
        custid = Session["custid"].ToString();
        dt = DateTime.Parse(DateTime.Now.ToString("MM/dd/yy"));
        dt1 = dt.ToShortDateString();
        da = new SqlDataAdapter("select * from question where custid='" + custid + "'", conn);
        da.Fill(ds, "cus");
        if (ds.Tables["cus"].Rows.Count > 0)
        {
            string pno = ds.Tables["cus"].Rows[0][2].ToString();
            // da = new SqlDataAdapter("select * from supplprod_tb where sno='" + pno + "' and Status='Avaliable'", conn);
            da = new SqlDataAdapter(" select p.sno,p.supplierid,p.prodname,p.pno,p.pname,q.cost,p.logo from supplprod_tb as p join question as q on p.sno=q.pno where q.custid='" + custid + "'", conn);
            da.Fill(ds, "sp");
            GridView1.DataSource = ds.Tables["sp"];
            GridView1.DataBind();
            // griddetails();
        }
        else
        {
        }
    }
    void griddetails()
    {
        da = new SqlDataAdapter("select p.pno,p.pname,q.cost from supplprod_tb as p join question as q on p.sno=q.pno where q.custid='"+custid+"'",conn);
        da.Fill(ds, "de");
        GridView2.DataSource = ds.Tables["de"];
        GridView2.DataBind();


    }
    void sno1()
    {
        da = new SqlDataAdapter("select count(sno) from cart_tb", conn);
        da.Fill(ds, "ss");
        int k = int.Parse(ds.Tables["ss"].Rows[0][0].ToString());
        if (k > 0)
        {
            cmd = new SqlCommand("select max(sno) from cart_tb", conn);
            dr = cmd.ExecuteReader();
            dr.Read();
            int i = int.Parse(dr[0].ToString());
            dr.Close();
            sno = i + 1;
        }
        else
        {
            sno = 1;
        }


    }
    protected void LinkButton1_Click(object sender, CommandEventArgs e)
    {
        if (custid != "")
        {
            sno1();
            arg = e.CommandArgument.ToString();
            da = new SqlDataAdapter("select * from supplprod_tb where sno='" + arg + "'", conn);
            da.Fill(ds, "arg");
            string pno = ds.Tables["arg"].Rows[0][2].ToString();
            string prodname = ds.Tables["arg"].Rows[0][3].ToString();
            string pname = ds.Tables["arg"].Rows[0][4].ToString();
            float price = float.Parse(ds.Tables["arg"].Rows[0][5].ToString());
            string logo = ds.Tables["arg"].Rows[0][8].ToString();
            da = new SqlDataAdapter("insert into cart_tb values('" + sno + "','" + custid + "','" + pno + "','" + prodname + "','" + pname + "','" + price + "','" + logo + "','" + System.DateTime.Now.ToShortDateString() + "','" + 1 + "','" + price + "')", conn);
            da.SelectCommand.ExecuteNonQuery();
        }
    }
}
