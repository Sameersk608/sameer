using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
/// <summary>
/// Summary description for Dbconn
/// </summary>
public class Dbconn
{  

        string cont;
        public Dbconn()
        {
            cont = "Data Source=NAAZNEEN-PC\\SQLEXPRESS;Initial Catalog=secure;Integrated Security=True";
                //"Server=lab4\\SQLEXPRESS;Database=secure;integrated security=sspi";
        }
        public string conn
        {
            get
            {
                return cont;
            }
            set
            {
            }
        }
    }

