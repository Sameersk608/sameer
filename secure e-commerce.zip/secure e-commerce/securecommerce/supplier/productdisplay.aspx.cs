using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class supplier_productdisplay : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        if (this.IsPostBack == false)
        {
            prod();
        }
        da = new SqlDataAdapter("select * from product_tb",conn);
        da.Fill(ds, "gp");
        GridView1.DataSource = ds.Tables["gp"];
        GridView1.DataBind();
    }
    void prod()
    {
        da = new SqlDataAdapter("select * from product_tb", conn);
        da.Fill(ds, "prod");
        ddlpname.DataSource = ds.Tables["prod"];
        ddlpname.DataTextField = "pno";
        ddlpname.DataValueField = "prodname";
        ddlpname.DataBind();
        ddlpname.Items.Insert(0, "--Select productId--");
        ddlpname.Dispose();
    }
    protected void ddlpname_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlpname.SelectedIndex != 0)
        {
            da = new SqlDataAdapter("select * from supplprod_tb where pno='" + ddlpname.SelectedItem.Text + "'", conn);
            da.Fill(ds, "details");
            GridView2.DataSource = ds.Tables["details"];
            GridView2.DataBind();
        }
    }
}
