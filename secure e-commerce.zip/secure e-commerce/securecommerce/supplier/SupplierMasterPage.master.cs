using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class supplier_SupplierMasterPage : System.Web.UI.MasterPage
{
    string suppid;
    SqlConnection conn;
    Dbconn con;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
       // suppid = Session["suppid"].ToString();

        LinkButton7.Visible = false;
        lblOr.Visible = false;
        LinkButton8.Visible = false;
        lblName.Text = Convert.ToString(Session["SupName"]);
    }
    protected void lnkentcategory_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/productdetails.aspx");
    }
     protected void lnkentproddetails_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/supplierproductdetails.aspx");
    }
    protected void lnkviewprod_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/productdisplay.aspx");
    }
    protected void lnkvieworders_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/vieworders.aspx");
    }
    protected void lnkcustorderlist_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/custorderlist.aspx");
    }
    protected void lnkmodifyprod_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/modifyproddetails.aspx");
    }
    protected void lnkprodsuppbyorder_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/supplierproducts.aspx");
    }
    protected void lnkmodifyprofile_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/modifysuppl.aspx");
    }
    protected void lnkpwd_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/changepassword.aspx");
    }
    protected void lnklogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/homepage1.aspx");
    }
      protected void lnkans_Click(object sender, EventArgs e)
    {
        Response.Redirect ("~/supplier/answers.aspx");
    }
}
