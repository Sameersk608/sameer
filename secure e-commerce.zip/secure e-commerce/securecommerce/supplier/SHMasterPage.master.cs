using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class supplier_SHMasterPage : System.Web.UI.MasterPage
{
    SqlConnection conn;
    Dbconn con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        if (this.IsPostBack == false)
        {
            prod();
        }
    }
    void prod()
    {
        da = new SqlDataAdapter("select * from product_tb", conn);
        da.Fill(ds, "prod");
        ddlpname.DataSource = ds.Tables["prod"];
        ddlpname.DataTextField = "prodname";
        ddlpname.DataValueField = "pno";
        ddlpname.DataBind();
        ddlpname.Items.Insert(0, "--Select Categories--");
        ddlpname.Dispose();
        LinkButton11.Visible = false;
        LinkButton7.Visible = false;
        lblOr.Visible = false;
        LinkButton8.Visible = false;
        lblName.Text = Convert.ToString(Session["SupName"]);
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "" && ddlpname.SelectedIndex != 0)
        {
            string pno = ddlpname.SelectedValue;
            Session["pno"] = pno;
            Session["name"] = "";
            LinkButton11.Visible = false;
            LinkButton7.Visible = true;
            lblOr.Visible = true;
            LinkButton8.Visible = true;
            lblName.Text = "";
            Session["SupName"] = "";
            Response.Redirect("~/supplier/shopprod1.aspx");
        }
        else
        {
            string pno = ddlpname.SelectedValue;
            string name = TextBox1.Text;
            Session["pno"] = pno;
            Session["name"] = name;
            LinkButton11.Visible = true;
            LinkButton7.Visible = false;
            lblOr.Visible = false;
            LinkButton8.Visible = false;
            lblName.Text = Convert.ToString(Session["SupName"]);
           // Response.Redirect("~/supplier/shopprod1.aspx");
        }
    }
    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/suppLogin.aspx");
    }
    protected void LinkButton8_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/supplier/supllierdetails.aspx");
    }
    protected void lnkadmin_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/admin/adminlogin.aspx");
    }
}
