using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class supplier_supplierproducts : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        if (this.IsPostBack == false)
        {
            supp();
        }
    }
    void supp()
    {
        da = new SqlDataAdapter("select * from supplierdetail_tb", conn);
        da.Fill(ds, "supp");
        ddlsuppid.DataSource = ds.Tables["supp"];
        ddlsuppid.DataTextField = "supplierid";
        ddlsuppid.DataValueField = "supplierid";
        ddlsuppid.DataBind();
        ddlsuppid.Items.Insert(0,"--Select SupplierId--");
        ddlsuppid.Dispose();
    }
    protected void ddlsuppid_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlsuppid.SelectedIndex != 0)
        {
            Label3.Text = ddlsuppid.SelectedValue;
            da = new SqlDataAdapter("select * from supplprod_tb where supplierid='"+ddlsuppid.SelectedValue+"'", conn);
            da.Fill(ds, "details");
            GridView1.DataSource = ds.Tables["details"];
            GridView1.DataBind();
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        da = new SqlDataAdapter("select * from supplprod_tb where supplierid='" + Label3.Text+ "'", conn);
        da.Fill(ds, "details");
        GridView1.DataSource = ds.Tables["details"];
        GridView1.DataBind();
    }
}
