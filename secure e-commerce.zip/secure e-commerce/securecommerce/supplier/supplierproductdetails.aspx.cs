using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class supplier_supplierproductdetails : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    int rowcnt;
    int cnt;
    string iname;
    int sno;
    DateTime dt;
    string dt1;
    string suppid;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        dt = DateTime.Parse(DateTime.Now.ToString("MM/dd/yy"));
        dt1 = dt.ToString("dd/MM/yyyy");
        suppid = Session["suppid"].ToString();
        if (this.IsPostBack == false)
        {
            prod();
        }
    }
    void prod()
    {
        da = new SqlDataAdapter("select * from product_tb", conn);
        da.Fill(ds, "prod");
        ddlpid.DataSource = ds.Tables["prod"];
        ddlpid.DataTextField = "pno";
        ddlpid.DataValueField = "prodname";
        ddlpid.DataBind();
        ddlpid.Items.Insert(0, "--Select--");
        ddlpid.Dispose();
    }
    void sno1()
    {
        da = new SqlDataAdapter("select count(sno) from supplprod_tb", conn);
        da.Fill(ds,"ss");
        int k = int.Parse(ds.Tables["ss"].Rows[0][0].ToString());
        if (k > 0)
        {
            cmd = new SqlCommand("select max(sno) from supplprod_tb", conn);
            dr = cmd.ExecuteReader();
            dr.Read();
            int i =int.Parse(dr[0].ToString());
            dr.Close();
            sno = i+ 1;
        }
        else
        {
            sno = 1;
        }
       

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
          sno1();
        if (FileUpload1.HasFile == true)
        {
            string imgpath = this.FileUpload1.FileName;
            FileUpload1.SaveAs(Server.MapPath("~//images//" + imgpath.ToString()));
           iname = "~/images/" + imgpath.ToString();
         }
        string status;
         if (CheckBox1.Checked == true)
            {
               status="Avaliable";
            }
            else
            {
                 status="Not Avaliable";
            }            
            lblsid.Text = suppid;
            da = new SqlDataAdapter("insert into supplprod_tb values('" + sno + "','" + lblsid.Text + "','" + ddlpid.SelectedItem.Text + "','" + lblpname.Text + "','" + txtpname.Text + "','" + float.Parse(txtprice.Text) + "','" + txtcname.Text + "','" + txtdesc.Text + "','" + iname + "','" + status + "','" + txtship.Text + "','" + dt + "')", conn);
            int i = da.SelectCommand.ExecuteNonQuery();
            if (i == 1)
            {
             lblmsg.Text = "Updated";
            }
    }
    protected void ddlpid_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlpid.SelectedIndex != 0)
        {
            lblpname.Text = ddlpid.SelectedValue;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        ddlpid.SelectedIndex = 0;
        lblpname.Text = "";
        txtpname.Text = "";
        txtcname.Text = "";
        txtprice.Text = "";
        txtdesc.Text = "";
        txtdesc.Text = "";
        txtship.Text = "";
        CheckBox1.Checked = false;
    }
}






