using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class supplier_suppLogin : System.Web.UI.Page
{
    Dbconn con;
    SqlConnection conn;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    //SqlCommand cmd;
    //SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
       Session["SupName"] = "";
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        da = new SqlDataAdapter("select supplierid,login,password from supplierdetail_tb where login=@username and password=@pwd", conn);
        da.SelectCommand.Parameters.AddWithValue("@username", txtuname.Text);
        da.SelectCommand.Parameters.AddWithValue("@pwd", txtpwd.Text);
        da.Fill(ds, "Login");
        if (ds.Tables["Login"].Rows.Count > 0)
        {
            string suppid = ds.Tables["login"].Rows[0][0].ToString();
            string suppName = ds.Tables["login"].Rows[0][1].ToString();
            Session["suppid"] = suppid;
            Session["SupName"] = suppName;
            Response.Redirect("~/supplier/homepages.aspx");
        }
    }

   

}

