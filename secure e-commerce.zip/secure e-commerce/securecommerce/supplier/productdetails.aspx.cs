using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class admin_productdetails : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
   
    string productno;
    int rowcnt;
    int cnt;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        
        prodno();
    }
    void prodno()
    {
        try
        {
            con = new Dbconn();
            conn = new SqlConnection(con.conn.ToString());
            conn.Open();
            cmd = new SqlCommand("select count(*) from dbo.product_tb", conn);
            dr = cmd.ExecuteReader();
            dr.Read();
            rowcnt = int.Parse(dr[0].ToString());
            dr.Close();
            if (rowcnt > 0)
            {
                cmd = new SqlCommand("select max(pno) from dbo.product_tb", conn);
                dr = cmd.ExecuteReader();
                dr.Read();
                productno = dr[0].ToString();
                cnt = int.Parse(productno.Substring(2)) + 1;
                dr.Close();
                if (cnt <= 9)
                {
                    productno = "PR0000" + cnt.ToString();
                }
                else if (cnt < 99)
                {
                    productno = "PR000" + cnt.ToString();
                }
                else if (cnt < 999)
                {
                    productno = "PR00" + cnt.ToString();
                }
                else if (cnt < 9999)
                {
                    productno = "PR0" + cnt.ToString();
                }
                else if (cnt < 99999)
                {
                    productno = "PR" + cnt.ToString();
                }
            }
            else
            {
                productno = "PR00001";
            }
            lblproductno1.Text = productno;
        }
        catch (Exception ex)
        {
            lblmsg1.Text = ex.Message;
        }
        finally
        {
            conn.Close();
        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //prodno();
            con = new Dbconn();
            conn = new SqlConnection(con.conn.ToString());
            conn.Open();
            da = new SqlDataAdapter("dbo.product_sp", conn);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@pno", productno);
            da.SelectCommand.Parameters.AddWithValue("@pname", txtname.Text);
           // da.SelectCommand.Parameters.AddWithValue("@cost", txtcost.Text);
            int i = da.SelectCommand.ExecuteNonQuery();
            if (i == 1)
            {
                lblmsg1.Attributes.Add("style", "color:blue;");
                lblmsg1.Text = "<b>product details inserted</b>";
            }
            else
            {
                lblmsg1.Text = "<b>product details not inserted</b>";
            }
            btnnew.Visible = true;
            btnsubmit.Visible = false;
        }
        catch (Exception ex)
        {
            lblmsg1.Text = ex.Message;
        }
        finally
        {
            conn.Close();
        }
    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        prodno();
        txtname.Text = "";
       // txtcost.Text = "";
        lblmsg1.Text = "";
        btnsubmit.Visible = true;
        btnnew.Visible = false;
    }
}
