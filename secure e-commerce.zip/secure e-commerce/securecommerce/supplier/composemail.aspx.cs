using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;
public partial class supplier_composemail : System.Web.UI.Page
{
    string fromid = String.Empty;
    System.Net.Mail.MailMessage msg;
    string cust, supp;
    SqlConnection conn;
    Dbconn con;
    SqlDataAdapter da;
    DateTime dt;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        if (Session.Count > 0)
        {
            cust = Session["cust"].ToString();
            supp = Session["supp"].ToString();
        }
        dt = DateTime.Parse(System.DateTime.Now.ToString());
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            da = new SqlDataAdapter("insert into mailsent_tb values('" + cust + "','" + supp + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + dt.ToString() + "')", conn);
            int i = da.SelectCommand.ExecuteNonQuery();
            msg = new System.Net.Mail.MailMessage("puvvada.rajesh557@gmail.com", TextBox1.Text);
            SmtpClient smtp = new SmtpClient();
            smtp.Credentials = new NetworkCredential("puvvada.rajesh557", "9949398287");
            msg.Subject = TextBox2.Text;
            msg.Body = TextBox3.Text;
            msg.Priority = MailPriority.High;
            msg.IsBodyHtml = true;
            smtp.EnableSsl = true;
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.Send(msg);
            TextBox3.Text = "";
            TextBox2.Text = "";          
            if (i == 1)
            {
                lblmsg.Text = "Msg is sent.";
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.Message.ToString();
        }



        //try
        //{
        //    if (FileUpload1.HasFile == true)
        //    {                
        //        int size = FileUpload1.PostedFile.ContentLength;
        //        if (size > 0)
        //        {
        //            System.Web.Mail.MailMessage msg = new MailMessage();
        //            msg.From = "ankith1983@gmail.com";
        //            msg.To = TextBox1.Text;
        //            msg.Subject = TextBox2.Text;
        //            msg.Body = TextBox3.Text;
        //            string file = FileUpload1.FileName;
        //           FileUpload1.SaveAs(Server.MapPath("~\\Attach\\"+ file));

        //           MailAttachment attach = new MailAttachment(Server.MapPath("~/attach/" + file));
        //           msg.Attachments.Add(attach);
        //           SmtpMail.SmtpServer = "localhost";
        //           SmtpMail.Send(msg);

        //            Label1.Text = "sent";

        //        }
        //    }
        //}
        //catch (Exception ex)
        //{
        //    Label1.Text = ex.Message;
        //}
    }
}
