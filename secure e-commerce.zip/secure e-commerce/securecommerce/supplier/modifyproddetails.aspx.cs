using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class supplier_modifyproddetails : System.Web.UI.Page
{
    Dbconn con;
    SqlConnection conn;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    string suppid;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        suppid = Session["suppid"].ToString();
       // suppid = "SI00001";
        if (this.IsPostBack == false)
        {
            griddetails();
        }
    }
    void griddetails()
    {
        da = new SqlDataAdapter("select * from supplprod_tb where supplierid='"+suppid+"'", conn);
        da.Fill(ds, "details");
        GridView1.DataSource = ds.Tables["details"];
        GridView1.DataBind();
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        griddetails();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        griddetails();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Label cid = new Label();
        Label prod = new Label();
        TextBox pname = new TextBox();
        TextBox price = new TextBox();
        TextBox cmpy = new TextBox();
        TextBox desc = new TextBox();
        TextBox bid = new TextBox();
        TextBox ship = new TextBox();
        CheckBox ss = new CheckBox();
        CheckBox bs = new CheckBox();
       cid = (Label)GridView1.Rows[e.RowIndex].Cells[2].FindControl("lblcid");
       prod = (Label)GridView1.Rows[e.RowIndex].Cells[3].FindControl("lblprod");
        pname=(TextBox)GridView1.Rows[e.RowIndex].Cells[4].FindControl("txtpname");
        price = (TextBox)GridView1.Rows[e.RowIndex].Cells[5].FindControl("txtprice");
        cmpy = (TextBox)GridView1.Rows[e.RowIndex].Cells[6].FindControl("txtcomp");
        desc = (TextBox)GridView1.Rows[e.RowIndex].Cells[7].FindControl("txtdec");
       ship=(TextBox)GridView1.Rows[e.RowIndex].Cells[9].FindControl("txtship");
        ss = (CheckBox)GridView1.Rows[e.RowIndex].Cells[8].FindControl("CheckBox1");
        string status;
        if (ss.Checked == true)
        {
            status = "Avaliable";
        }
        else
        {
            status = "Not Avaliable";
        }
      
        da = new SqlDataAdapter("update supplprod_tb set pname='" + pname.Text + "',price='" +float.Parse(price.Text) + "',companyname='" + cmpy.Text + "',description='" + desc.Text + "',status='" + status + "',shipping='" +ship.Text + "' where sno='" +int.Parse(cid.Text)+ "'", conn);
        da.SelectCommand.ExecuteNonQuery();
        griddetails();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        griddetails();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Label cid = new Label();
        cid = (Label)GridView1.Rows[e.RowIndex].Cells[2].FindControl("lblcid");
        da = new SqlDataAdapter("delete supplprod_tb where sno='" + int.Parse(cid.Text) + "'", conn);
        da.SelectCommand.ExecuteNonQuery();
        griddetails();
    }
}
