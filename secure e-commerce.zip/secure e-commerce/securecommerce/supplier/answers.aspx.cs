using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class supplier_answers : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlDataAdapter da;
    DataSet ds = new DataSet(); 
    string suppid;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        suppid = Session["suppid"].ToString();
        if (this.IsPostBack == false)
        {
            cust();
        }

    }
    void cust()
    {
        da=new SqlDataAdapter("select * from question where suppid='"+suppid+"'",conn);
        da.Fill(ds, "de");
        ddlcustid.DataSource = ds.Tables["de"];
        ddlcustid.DataTextField = "custid";
        ddlcustid.DataValueField = "pno";
        ddlcustid.DataBind();
        ddlcustid.Items.Insert(0, "--Select--");
    }
    protected void ddlcustid_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlcustid.SelectedIndex != 0)
        {
            da = new SqlDataAdapter("select * from customerdetail_tb where custid='" + ddlcustid.SelectedItem.Text + "'", conn);
            da.Fill(ds, "cus");
            lblcname.Text=ds.Tables["cus"].Rows[0][1].ToString();
            lblcname.Text+=ds.Tables["cus"].Rows[0][2].ToString();
            lblemail.Text=ds.Tables["cus"].Rows[0][8].ToString();
            lblph.Text=ds.Tables["cus"].Rows[0][9].ToString();
            da=new SqlDataAdapter("select * from supplprod_tb where sno='"+ddlcustid.SelectedValue+"'",conn);
            da.Fill(ds, "pr");
            lblpid.Text=ds.Tables["pr"].Rows[0][0].ToString();
            lblpname.Text=ds.Tables["pr"].Rows[0][4].ToString();
            lblprice.Text=ds.Tables["pr"].Rows[0][5].ToString();
            da=new SqlDataAdapter("select * from question where custid='"+ddlcustid.SelectedItem.Text+"' and suppid='"+suppid+"'",conn);
            da.Fill(ds, "supp");
            lblenc.Text=ds.Tables["supp"].Rows[0][4].ToString();
            lblper.Text=ds.Tables["supp"].Rows[0][5].ToString();
            lblqlevel.Text=ds.Tables["supp"].Rows[0][3].ToString();
        }
    }
    protected void txtench_TextChanged(object sender, EventArgs e)
    {
        int txtquant = 0;
        int.TryParse(txtqu.Text, out txtquant);
        int txtEnchancement = 0;
        int.TryParse(txtench.Text, out txtEnchancement);
        int tot = txtquant + txtEnchancement;
        txttot.Text = tot.ToString();
    }
    protected void txtper_TextChanged(object sender, EventArgs e)
    {
        int txtquant = 0;
        int.TryParse(txtqu.Text, out txtquant);
        int txtEnchancement = 0;
        int.TryParse(txtench.Text, out txtEnchancement);
        int txtPers = 0;
        int.TryParse(txtper.Text, out txtPers);
        int tot = txtquant + txtEnchancement + txtPers;
        txttot.Text = tot.ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
      
        da = new SqlDataAdapter("update question set cost='" + float.Parse(txtcost.Text) + "'  where custid='" + ddlcustid.SelectedItem.Text + "' and suppid='" + suppid + "'", conn);
        int i=da.SelectCommand.ExecuteNonQuery();
      
        {
            lblmsg.Text = "Updated";
        }
    }
    protected void txttot_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtqu_TextChanged(object sender, EventArgs e)
    {

    }
}
