using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class supplier_custorderlist : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    string suppid;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        suppid = Session["suppid"].ToString();
        if (this.IsPostBack == false)
        {
            cust();
        }
    }
    void cust()
    {
        da = new SqlDataAdapter("select distinct c.custid from cart_tb as c join supplprod_tb as s on s.pname=c.pname where s.supplierid='"+suppid+"'", conn);
        da.Fill(ds, "cust");
        ddlcustid.DataSource = ds.Tables["cust"];
        ddlcustid.DataTextField = "custid";
        ddlcustid.DataValueField = "custid";
        ddlcustid.DataBind();
        ddlcustid.Items.Insert(0, "--Select Customer--");
        ddlcustid.Dispose();
    }
    protected void ddlcustid_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlcustid.SelectedIndex != 0)
        {
            Label6.Visible = true;
            Label7.Visible = true;
            Label2.Visible = true;
            Label3.Visible = true;
            Label4.Visible = true;
            Label5.Visible = true;
            GridView1.Dispose();
            da = new SqlDataAdapter("select * from customerdetail_tb where custid='" + ddlcustid.SelectedValue + "'", conn);
            da.Fill(ds, "details");
            lblcustname.Text = ds.Tables["details"].Rows[0][1].ToString();
            lblcustname.Text += ds.Tables["details"].Rows[0][2].ToString();
            lblphno.Text=ds.Tables["details"].Rows[0][9].ToString();
            lbladdr.Text = ds.Tables["details"].Rows[0][3].ToString();
            lblemail.Text=ds.Tables["details"].Rows[0][8].ToString();
            da=new SqlDataAdapter("select * from cart_tb as c join supplprod_tb as s on s.pname=c.pname where s.supplierid='"+suppid+"' and c.custid='"+ddlcustid.SelectedValue+"'",conn);
            da.Fill(ds,"cc");
            GridView1.DataSource = ds.Tables["cc"];
            GridView1.DataBind();
        }
    }
    protected void LinkButton1_Click(object sender, CommandEventArgs e)
    {
        string arg = e.CommandArgument.ToString();
        da = new SqlDataAdapter("select c.pno,c.prodname,c.price,c.date,c.qtyordered,c.totamt,c.custid from cart_tb as c join supplprod_tb as s on s.pname=c.pname where s.supplierid='" + suppid + "' and c.custid='" + arg + "'", conn);
        da.Fill(ds, "or");
        GridView2.DataSource = ds.Tables["or"];
        GridView2.DataBind();
    }
    protected void LinkButton2_Click(object sender,CommandEventArgs  e)
    {
        string arg = e.CommandArgument.ToString();
        Session["cust"] = arg;
        Session["supp"] = suppid;
        Response.Redirect("~/supplier/composemail.aspx");
    }
}
