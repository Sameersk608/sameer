using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class supplier_supllierdetails : System.Web.UI.Page
{
    SqlConnection conn;
    Dbconn con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    int rowcnt;
    int cnt;
    string sid;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        supplierid();
        if (this.IsPostBack == false)
        {
            state();
            country();
            city();
        }
    }
    void supplierid()
    {
        try
        {
            con = new Dbconn();
            conn = new SqlConnection(con.conn.ToString());
            conn.Open();
            cmd = new SqlCommand("select count(*) from supplierdetail_tb", conn);
            dr = cmd.ExecuteReader();
            dr.Read();
            rowcnt = int.Parse(dr[0].ToString());
            dr.Close();
            if (rowcnt > 0)
            {
                cmd = new SqlCommand("select max(supplierid) from supplierdetail_tb", conn);
                dr = cmd.ExecuteReader();
                dr.Read();
                sid = dr[0].ToString();
                cnt = int.Parse(sid.Substring(2)) + 1;
                dr.Close();
                if (cnt <= 9)
                {
                    sid = "SI0000" + cnt.ToString();
                }
                else if (cnt < 99)
                {
                    sid = "SI000" + cnt.ToString();
                }
                else if (cnt < 999)
                {
                    sid = "SI00" + cnt.ToString();
                }
                else if (cnt < 9999)
                {
                    sid = "SI0" + cnt.ToString();
                }
                else if (cnt < 99999)
                {
                    sid = "SI" + cnt.ToString();
                }
            }
            else
            {
                sid = "SI00001";
            }
           
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.Message;
        }
        finally
        {
            conn.Close();
        }
    }
    void state()
    {
        da = new SqlDataAdapter("select * from dbo.state_tb", conn);
        da.Fill(ds, "state");
        ddlstate.DataSource = ds.Tables["state"];
        ddlstate.DataTextField = "statename";
        ddlstate.DataValueField = "stateid";
        ddlstate.DataBind();
        ddlstate.Items.Insert(0, "--Select--");
        ddlstate.Dispose();
    }
    void country()
    {
        da = new SqlDataAdapter("select * from dbo.country_tb", conn);
        da.Fill(ds, "country");
        ddlcountry.DataSource = ds.Tables["country"];
        ddlcountry.DataTextField = "cname";
        ddlcountry.DataValueField = "cno";
        ddlcountry.DataBind();
        ddlcountry.Items.Insert(0, "--Select--");
        ddlcountry.Dispose();
    }
    void city()
    {
        da = new SqlDataAdapter("select * from dbo.city_tb", conn);
        da.Fill(ds, "city");
        ddlcity.DataSource = ds.Tables["city"];
        ddlcity.DataTextField = "cityname";
        ddlcity.DataValueField = "cityid";
        ddlcity.DataBind();
        ddlcity.Items.Insert(0, "--Select--");
        ddlcity.Dispose();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        con = new Dbconn();
        conn = new SqlConnection(con.conn.ToString());
        conn.Open();
        da = new SqlDataAdapter("supplierdetail_sp", conn);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        da.SelectCommand.Parameters.AddWithValue("@sid", sid);
        da.SelectCommand.Parameters.AddWithValue("@fname",txtfname.Text);
        da.SelectCommand.Parameters.AddWithValue("@lname",txtlname.Text);
        da.SelectCommand.Parameters.AddWithValue("@addr",txtaddr.Text);
        da.SelectCommand.Parameters.AddWithValue("@city",ddlcity.SelectedItem.Text);
        da.SelectCommand.Parameters.AddWithValue("@state",ddlstate.SelectedItem.Text);
        da.SelectCommand.Parameters.AddWithValue("@country",ddlcountry.SelectedItem.Text);
        da.SelectCommand.Parameters.AddWithValue("@zip",txtzip.Text);
        da.SelectCommand.Parameters.AddWithValue("@emailid",txtemail.Text);
        da.SelectCommand.Parameters.AddWithValue("@phno",txtphno.Text);
        da.SelectCommand.Parameters.AddWithValue("@credit",txtcredit.Text);
        da.SelectCommand.Parameters.AddWithValue("@login",txtloginid.Text);
        da.SelectCommand.Parameters.AddWithValue("@pwd",txtpwd.Text);
        da.SelectCommand.Parameters.AddWithValue("@date",System.DateTime.Now.ToString());
       int i= da.SelectCommand.ExecuteNonQuery();
       if (i == 1)
       {
           lblmsg.Text = "Registeration Successful ";
       }
       else
       {
           lblmsg.Text = "Registeration not Successful ";
       }
    }
    protected void txtloginid_TextChanged(object sender, EventArgs e)
    {
        conn.Open();
        cmd = new SqlCommand("select count(login) from supplierdetail_tb where login='" + txtloginid.Text + "'", conn);
        dr = cmd.ExecuteReader();
        dr.Read();
        rowcnt = int.Parse(dr[0].ToString());
        dr.Close();
        if (rowcnt > 0)
        {
            lblmsg1.Text = "UserName already exists";
        }
        else
        {
        }
    }
}
